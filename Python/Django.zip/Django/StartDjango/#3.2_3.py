class Car():
    wheels = 4
    door = 4
    windows = 4
    seats = 4
    
    def start(self):
        print(self.door)
        print("I Started")
 
porche = Car()
porche.color = "Sexy Color"
porche.start()