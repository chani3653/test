from django.apps import AppConfig


class ConversationsConfig(AppConfig):
    name = 'conversations'
